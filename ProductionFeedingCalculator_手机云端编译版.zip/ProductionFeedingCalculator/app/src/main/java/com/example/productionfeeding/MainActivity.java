package com.example.productionfeeding;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(242,243,245);
    private static final int WHITE = Color.WHITE;
    private static final int BORDER = Color.rgb(199,206,216);
    private static final int TEXT = Color.rgb(32,33,36);
    private static final int LABEL = Color.rgb(100,116,139);
    private static final int BLUE = Color.rgb(37,99,235);
    private static final int SUMMARY = Color.rgb(238,242,246);

    private LinearLayout body;
    private TextView fRemain, fProd, fWeight;
    private int seq = 0;
    private final List<Row> rows = new ArrayList<>();
    private SharedPreferences prefs;
    private final DecimalFormat weightFmt = new DecimalFormat("0.00");
    private final DecimalFormat unitFmt = new DecimalFormat("0.0000");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        prefs = getSharedPreferences("data", MODE_PRIVATE);
        buildUi();
        load();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(10), dp(12), dp(10), dp(22));
        scroll.addView(page, new ScrollView.LayoutParams(-1, -1));

        TextView title = text("生产投料计算表", 24, TEXT, true);
        page.addView(title, lp(-1, -2, 0, 0, 0, 2));
        TextView sub = text("输入数据后实时计算 · 可直接修改生产件数和生产重量", 12, Color.rgb(115,119,125), false);
        page.addView(sub, lp(-1, -2, 0, 0, 0, 10));

        LinearLayout rule = box(WHITE, 1, BORDER, 8);
        rule.setPadding(dp(11), dp(9), dp(11), dp(9));
        TextView r1 = text("计算规则", 13, TEXT, true);
        rule.addView(r1, lp(-1,-2,0,0,0,2));
        TextView r2 = text("生产件数 = 总件数 − 减数 − 附加减数 − 剩余件数\n单件重量 = 总质量 ÷ 总件数\n生产重量 = 单件重量 × 生产件数", 12, Color.rgb(85,91,98), false);
        rule.addView(r2, lp(-1,-2,0,0,0,0));
        page.addView(rule, lp(-1,-2,0,0,0,10));

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        page.addView(body, lp(-1,-2,0,0,0,0));

        LinearLayout summary = box(SUMMARY, 1, BORDER, 9);
        summary.setPadding(dp(8),dp(6),dp(8),dp(6));
        TextView st = text("合计", 17, TEXT, true); st.setGravity(Gravity.CENTER);
        summary.addView(st, lp(-1,-2,0,0,0,5));
        LinearLayout sums = new LinearLayout(this); sums.setOrientation(LinearLayout.VERTICAL);
        sums.addView(summaryLine("剩余件数", fRemain = text("0 件",19,TEXT,true)), lp(-1,-2,0,0,0,2));
        sums.addView(summaryLine("生产件数", fProd = text("0 件",21,BLUE,true)), lp(-1,-2,0,0,0,2));
        sums.addView(summaryLine("生产重量", fWeight = text("0.00 kg",21,BLUE,true)), lp(-1,-2,0,0,0,0));
        summary.addView(sums, lp(-1,-2,0,0,0,0));
        page.addView(summary, lp(-1,-2,0,0,0,10));

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setGravity(Gravity.CENTER);
        Button add = button("＋ 添加一行", true); add.setOnClickListener(v -> addRow(null));
        Button clear = button("清空", false); clear.setOnClickListener(v -> { body.removeAllViews(); rows.clear(); seq=0; addRow(null); save(); });
        actions.addView(add, lp(0,dp(50),1,0,0,0)); actions.addView(clear, lp(0,dp(50),1,8,0,0));
        page.addView(actions, lp(-1,-2,0,0,0,0));

        setContentView(scroll);
    }

    private View summaryLine(String label, TextView value) {
        LinearLayout l = new LinearLayout(this); l.setGravity(Gravity.CENTER_VERTICAL);
        TextView a = text(label,12,LABEL,true); l.addView(a, lp(0,dp(34),1,0,0,0));
        value.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); l.addView(value, lp(0,dp(34),1,4,0,0));
        return l;
    }

    private void addRow(RowData data) {
        Row r = new Row(this); rows.add(r); seq++; r.index.setText(String.valueOf(seq));
        if(data != null){ r.total.setText(data.total); r.deduct.setText(data.deduct); r.addDeduct.setText(data.addDeduct); r.mass.setText(data.mass); r.remain.setText(data.remain); r.prod.setText(data.prod); r.pm.setText(data.pm); }
        r.total.setOnFocusChangeListener((v,has)->{ if(!has) calculate(); });
        r.deduct.setOnFocusChangeListener((v,has)->{ if(!has) normalizeDeduct(r.deduct); calculate(); });
        r.addDeduct.setOnFocusChangeListener((v,has)->{ if(!has) calculate(); });
        r.mass.setOnFocusChangeListener((v,has)->{ if(!has) calculate(); });
        r.remain.setOnFocusChangeListener((v,has)->{ if(has){r.remainManual=true;r.prodManual=false;r.pmManual=false;} else calculate(); });
        r.prod.setOnFocusChangeListener((v,has)->{ if(has){r.prodManual=true;r.remainManual=false;r.pmManual=false;} else calculate(); });
        r.pm.setOnFocusChangeListener((v,has)->{ if(has) r.pmManual=true; else calculate(); });
        r.delete.setOnClickListener(v->{ body.removeView(r.card); rows.remove(r); renumber(); calculate(); save(); });
        body.addView(r.card, lp(-1,-2,0,0,0,9));
        calculate();
    }

    private void normalizeDeduct(EditText e){
        double n=num(e); if(Double.isNaN(n)) n=2; int d=(int)Math.floor(n); d=Math.max(1,Math.min(10,d)); e.setText(String.valueOf(d));
    }

    private void renumber(){seq=0; for(Row r:rows) r.index.setText(String.valueOf(++seq));}

    private void calculate(){
        int totalCount=0,totalProd=0,totalRemain=0; double totalWeight=0;
        for(Row r:rows){
            double total=num(r.total), mass=num(r.mass), deduct=num(r.deduct); if(r.deduct.getText().toString().trim().isEmpty()) deduct=2;
            deduct=Math.max(1,Math.min(10,Math.floor(deduct)));
            double addDeduct=Math.max(0,Math.floor(num(r.addDeduct)));
            int remain=(int)Math.max(0,Math.floor(num(r.remain)));
            if(total<=0){r.unit.setText("—"); if(!r.prodManual)r.prod.setText(""); if(!r.pmManual)r.pm.setText(""); continue;}
            if(total<deduct+addDeduct+remain){r.unit.setText("数据不足"); continue;}
            int prod, actualRemain;
            if(r.prodManual){prod=(int)Math.max(0,Math.floor(num(r.prod))); actualRemain=(int)Math.max(0,total-deduct-addDeduct-prod); r.remain.setText(String.valueOf(actualRemain));}
            else {actualRemain=remain; prod=(int)Math.max(0,total-deduct-addDeduct-actualRemain); r.prod.setText(String.valueOf(prod));}
            double unit=mass/total; double autoPm=unit*prod;
            if(!r.pmManual) r.pm.setText(weightFmt.format(autoPm));
            r.unit.setText(unitFmt.format(unit)+" kg");
            double actualPm=Math.max(0,num(r.pm));
            totalCount+=(int)Math.floor(total); totalWeight+=mass; totalProd+=prod; totalRemain+=actualRemain;
        }
        fRemain.setText(totalRemain+" 件"); fProd.setText(totalProd+" 件");
        double sumPm=0; for(Row r:rows) sumPm+=Math.max(0,num(r.pm)); fWeight.setText(weightFmt.format(sumPm)+" kg");
        save();
    }

    private void save(){ if(prefs==null)return; StringBuilder s=new StringBuilder(); for(Row r:rows){s.append(esc(r.total.getText().toString())).append('|').append(esc(r.deduct.getText().toString())).append('|').append(esc(r.addDeduct.getText().toString())).append('|').append(esc(r.mass.getText().toString())).append('|').append(esc(r.remain.getText().toString())).append('|').append(esc(r.prod.getText().toString())).append('|').append(esc(r.pm.getText().toString())).append('|').append(r.prodManual?1:0).append('|').append(r.pmManual?1:0).append(';');} prefs.edit().putString("rows",s.toString()).apply(); }
    private String esc(String s){return s.replace("|"," ").replace(";"," ");}
    private void load(){ String s=prefs.getString("rows",""); if(s.isEmpty()){for(int i=0;i<5;i++)addRow(null);return;} for(String x:s.split(";")){if(x.trim().isEmpty())continue; String[] a=x.split("\\|",-1); RowData d=new RowData(); if(a.length>0)d.total=a[0];if(a.length>1)d.deduct=a[1];if(a.length>2)d.addDeduct=a[2];if(a.length>3)d.mass=a[3];if(a.length>4)d.remain=a[4];if(a.length>5)d.prod=a[5];if(a.length>6)d.pm=a[6];addRow(d); if(rows.size()>0){Row r=rows.get(rows.size()-1);r.prodManual=a.length>7&&"1".equals(a[7]);r.pmManual=a.length>8&&"1".equals(a[8]);}} calculate(); }

    private double num(EditText e){try{String s=e.getText().toString().trim();return s.isEmpty()?0:Double.parseDouble(s);}catch(Exception ex){return 0;}}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(null,bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);return t;}
    private LinearLayout box(int bg,int sw,int stroke,int radius){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);GradientDrawable g=new GradientDrawable();g.setColor(bg);g.setStroke(dp(sw),stroke);g.setCornerRadius(dp(radius));l.setBackground(g);return l;}
    private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setAllCaps(false);b.setTextColor(primary?Color.WHITE:TEXT);GradientDrawable g=new GradientDrawable();g.setColor(primary?TEXT:WHITE);g.setStroke(dp(1),primary?TEXT:BORDER);g.setCornerRadius(dp(8));b.setBackground(g);return b;}
    private EditText input(String hint,boolean decimal){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.LTGRAY);e.setTextSize(19);e.setTextColor(TEXT);e.setGravity(Gravity.CENTER);e.setSingleLine(true);e.setPadding(dp(5),0,dp(5),0);e.setInputType(InputType.TYPE_CLASS_NUMBER|(decimal?InputType.TYPE_NUMBER_FLAG_DECIMAL:0));GradientDrawable g=new GradientDrawable();g.setColor(WHITE);g.setStroke(dp(1),Color.rgb(185,189,195));g.setCornerRadius(dp(7));e.setBackground(g);return e;}
    private LinearLayout line(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView label(String s){TextView t=text(s,12,LABEL,true);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private LinearLayout.LayoutParams lp(int w,int h,float weight,int l,int t,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h,weight);p.setMargins(dp(l),dp(t),dp(0),dp(b));return p;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}

    private class Row{
        LinearLayout card=line(); TextView index=text("1",18,Color.rgb(51,65,85),true); EditText total=input("总件数",false), deduct=input("2",false), addDeduct=input("0",false), mass=input("总质量",true), remain=input("剩余件数",false), prod=input("—",false), pm=input("—",true); TextView unit=text("—",17,Color.rgb(68,75,82),true); Button delete=button("×",false); boolean prodManual=false,remainManual=false,pmManual=false;
        Row(Context c){
            card.setBackgroundColor(WHITE); card.setPadding(dp(7),dp(7),dp(7),dp(7));
            GradientDrawable bg=new GradientDrawable();bg.setColor(WHITE);bg.setStroke(dp(1),BORDER);bg.setCornerRadius(dp(9));card.setBackground(bg);
            LinearLayout content=new LinearLayout(c);content.setOrientation(LinearLayout.VERTICAL);
            TextView n=index; n.setGravity(Gravity.CENTER); LinearLayout head=line(); head.addView(n,lp(dp(34),dp(52),0,0,0,0));
            LinearLayout top=line(); top.addView(total,lp(0,dp(52),1,5,0,0)); TextView m1=text("−",20,Color.DKGRAY,true);m1.setGravity(Gravity.CENTER);top.addView(m1,lp(dp(18),dp(52),0,3,0,0)); top.addView(deduct,lp(dp(62),dp(52),0,3,0,0));
            head.addView(top,lp(0,dp(52),1,5,0,0)); content.addView(head,lp(-1,-2,0,0,0,3));
            LinearLayout ad=line(); TextView al=label("附加减数");ad.addView(al,lp(0,dp(46),1,dp(39),0,0)); TextView m2=text("−",19,Color.DKGRAY,true);m2.setGravity(Gravity.CENTER);ad.addView(m2,lp(dp(18),dp(46),0,3,0,0));ad.addView(addDeduct,lp(dp(72),dp(46),0,3,0,0));content.addView(ad,lp(-1,-2,0,0,0,5));
            LinearLayout mr=box(Color.rgb(250,250,251),1,BORDER,7);mr.setPadding(dp(7),dp(5),dp(7),dp(5)); LinearLayout ml=line();ml.addView(label("总质量（kg）"),lp(dp(82),dp(44),0,0,0,0));ml.addView(mass,lp(0,dp(44),1,5,0,0));mr.addView(ml,lp(-1,-2,0,0,0,4)); LinearLayout rl=line();rl.addView(label("剩余件数"),lp(dp(82),dp(44),0,0,0,0));rl.addView(remain,lp(0,dp(44),1,5,0,0));mr.addView(rl,lp(-1,-2,0,0,0,0));content.addView(mr,lp(-1,-2,0,0,0,5));
            LinearLayout result=box(Color.rgb(247,248,249),1,Color.rgb(174,180,187),7); LinearLayout p=line();p.addView(label("生产件数"),lp(dp(62),dp(45),0,5,0,0));p.addView(prod,lp(0,dp(45),1,4,0,0));p.addView(text("件",11,Color.GRAY,false),lp(dp(22),dp(45),0,2,0,0));result.addView(p,lp(-1,-2,0,0,0,1)); LinearLayout w=line();w.addView(label("生产重量"),lp(dp(62),dp(45),0,5,0,0));w.addView(pm,lp(0,dp(45),1,4,0,0));w.addView(text("kg",11,Color.GRAY,false),lp(dp(22),dp(45),0,2,0,0));result.addView(w,lp(-1,-2,0,0,0,0));content.addView(result,lp(-1,-2,0,0,0,5));
            LinearLayout bottom=line(); TextView ul=label("单件重量");bottom.addView(ul,lp(dp(70),dp(42),0,5,0,0));bottom.addView(unit,lp(0,dp(42),1,0,0,0));delete.setText("×");bottom.addView(delete,lp(dp(48),dp(42),0,4,0,0));content.addView(bottom,lp(-1,-2,0,0,0,0));
            card.addView(content,lp(-1,-2,0,0,0,0));
        }
    }
    private static class RowData{String total="",deduct="2",addDeduct="0",mass="",remain="",prod="",pm="";}
}
