# 生产投料计算表 Android App

这是“生产投料计算表”的 Android 原生版本，针对约 6.39 英寸手机优化。

## 已实现
- 总件数 − 减数
- 附加减数单独一行
- 总质量与剩余件数放在同一个区域
- 生产件数、生产重量实时自动计算
- 生产件数/剩余件数互相联动
- 可手动修改生产重量
- 添加、删除、清空
- 本地自动保存，完全离线使用
- 竖屏显示

## 计算公式
生产件数 = 总件数 − 减数 − 附加减数 − 剩余件数

单件重量 = 总质量 ÷ 总件数

生产重量 = 单件重量 × 生产件数

## 手机无电脑编译 APK
项目自带 GitHub Actions 配置 `.github/workflows/build-apk.yml`。

把整个项目上传到 GitHub 仓库并推送到 `main` 后，GitHub 会自动编译 APK。

也可以在 GitHub 仓库的 `Actions` → `Build Android APK` → `Run workflow` 手动编译。

编译完成后：打开对应工作流 → 页面底部 `Artifacts` → 下载 `ProductionFeedingCalculator-debug-apk` → 解压 → 安装 `app-debug.apk`。

## Android Studio
如果以后有电脑，直接用 Android Studio 打开项目根目录即可。
